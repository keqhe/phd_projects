#!/usr/local/bin/python2.7
import sys, os, commands
import dpkt
import socket

if len(sys.argv) < 3:
	print "Usage: program pcapfile parsed_timestamp"
counter=0
ipcounter=0
tcpcounter=0
udpcounter=0



filename=sys.argv[1]
outfile = sys.argv[2]
w = open(outfile, 'w')

for ts, pkt in dpkt.pcap.Reader(open(filename,'r')):

    counter+=1
    eth=dpkt.ethernet.Ethernet(pkt) 
    if eth.type!=dpkt.ethernet.ETH_TYPE_IP:
       continue

    ip=eth.data
    ipcounter+=1

    #if socket.inet_ntoa(ip.src) == "10.26.1.4":
    #	continue
    if ip.p==dpkt.ip.IP_PROTO_TCP and len(eth) == 98: 
       tcpcounter+=1
       tcp = ip.data
       sec = int(ts)
       msec = (ts - int(ts))*1000000
       #flags
       fin_flag = ( tcp.flags & dpkt.tcp.TH_FIN )
       syn_flag = ( tcp.flags & dpkt.tcp.TH_SYN )
       ack_flag = ( tcp.flags & dpkt.tcp.TH_ACK )
       rst_flag = ( tcp.flags & dpkt.tcp.TH_RST )
       psh_flag = ( tcp.flags & dpkt.tcp.TH_PUSH)
       #print syn_flag, fin_flag, ack_flag, rst_flag, psh_flag, len(eth), sec, msec
       w.write('%d %f\n' % (sec, msec))

    if ip.p==dpkt.ip.IP_PROTO_UDP:
       udpcounter+=1

#print "Total number of packets in the pcap file: ", counter
#print "Total number of ip packets: ", ipcounter
#print "Total number of tcp packets: ", tcpcounter
#print "Total number of udp packets: ", udpcounter
