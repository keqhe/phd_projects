from __future__ import division
import os, sys, commands

if len(sys.argv) != 3:
	print 'Usage program input CDFfile'

f1 = sys.argv[1]
f2 = sys.argv[2]
w = open(f2, 'w')

global d_count
d_count = {}

for line in open(f1,'r'):
	line = line.strip()
	d = float(line)
	d = int(d)
	if not (d in d_count):
		d_count[d] = 1
	else:
		d_count[d] = d_count[d] + 1
keys = d_count.keys()
keys.sort()

total = 0
for k in keys:
	total += d_count[k]

global d_percent
d_percent = {}

for k in keys:
	d_percent[k] = d_count[k]/total

last = 0.0
for k in keys:
	d_percent[k] = d_percent[k] + last
	last = d_percent[k]
	w.write('%d %f\n' % (k, d_percent[k]))
w.close()
