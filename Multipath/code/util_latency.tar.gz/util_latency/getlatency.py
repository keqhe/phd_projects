import os, sys, commands

if (len(sys.argv)) < 5:
        print "Usage: program sender_out receiver_out pkt_count output"

f1 = sys.argv[1]
f2 = sys.argv[2]
pkt_count = int(sys.argv[3])
outfile = sys.argv[4]

w = open(outfile, 'w')
linecount = 0

global sender
global receiver
sender = {}
receiver = {} #key, value
for line in open(f1,'r'):
        line = line.strip()
        words = line.split()
        sec = long(words[0])
        micro = float(words[1])
        linecount += 1
        sender[linecount] = (sec, micro)

linecount = 0
for line in open(f2,'r'):
        line = line.strip()
        words = line.split()
        sec = long(words[0])
        micro = float(words[1])
        linecount += 1
        receiver[linecount] = (sec, micro)

print "probing latnecies in microseconds are listed below"
for i in xrange(1, pkt_count+1):
        d = (receiver[i][0] - sender[i][0])*1000000 + (receiver[i][1] - sender[i][1])
        print "Number"+str(i) , "%f" % (d,)
	w.write('%f\n' % (d,))
w.close()
