1. Before run the experiments, make sure that "nuttcp -S" is running on DCN26

2. Probing packets are sent from one interface (slot2a in a network namespace) tp another interface (slot1a)

3. Capture the probing packets (data) on the two interfaces of DCN26

4. Background traffic is generated on DCN21 using nuttcp

5. Till now, the generted traffic on DCN is around 7.4Gbps at the maximum rate, need to be FIXED
