#
#echo "current setting is listed below"
echo "clean tcpserver and tcpclient process on DCN1..."
echo "clean nuttcp process on DCN2..."
killall -9 tcpserver
killall -9 tcpclient
ssh hek@arldcn2.austin.ibm.com 'killall -9 nuttcp'

probe_count=1000
probe_interval=100000 #in micro seconds
#tcp server port is generated randomly within a range
port=`shuf -i 10000-65000 -n 1`

echo "start..."
echo "start tcpdump on two interfaces of DCN1..."
tcpdump -i eth2 -w server_XG.pcap host 10.2.1.3 &
ip netns exec net3 tcpdump -i eth3 -w client_XG.pcap &

echo "start the background traffic (in Mbps) and wait for 5 seconds for its stable running"
ssh hek@arldcn2.austin.ibm.com 'nuttcp -t -R10m -T300 10.2.1.1  1>/dev/null  2>&1 &'
sleep 5

echo "start tcp server and client on DCN26..."
./tcpserver $port $probe_count &
ip netns exec net3 ./tcpclient 10.2.1.1 $port $probe_count $probe_interval 
# parameters hostname port probing_count and probing interval in microseconds
sleep 3

echo "data should be recorded in the two server_XG.pcap and client_XG.pcap now"
echo "kill two processes which run tcpdump"
killall -2 tcpdump #send SIGINT to tcpdump
