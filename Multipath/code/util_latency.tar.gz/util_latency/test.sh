probe_count=20
probe_interval=2500000 #in micro seconds

./tcpserver $probe_count &
ip netns exec net2 ./tcpclient 10.26.1.2 8888 $probe_count $probe_interval &
