echo "processing the recorded data..."
python parse_pcap.py server_XG.pcap server_XG_timestamp.txt
python parse_pcap.py client_XG.pcap client_XG_timestamp.txt

echo "calculate the latencies..."
python getlatency.py client_XG_timestamp.txt server_XG_timestamp.txt $1 $2 $3

echo "done"
